#ifndef ITCASTCPP_H_
#define ITCASTCPP_H_

int fac(int n);
char *reverse(char *s);
int test(void);

#endif
